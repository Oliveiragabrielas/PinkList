# 🌌 PinkList — Lista de Compras Galáxia

Aplicativo de lista de compras desenvolvido com **React Native, Expo e TypeScript**, com interface futurista inspirada no universo.

## 🚀 Funcionalidades

- Adicionar produtos à lista de compras.
- Informar a quantidade de cada produto.
- Remover produtos individualmente.
- Atualizar automaticamente o contador de produtos.
- Validar campos vazios.
- Exibir mensagem quando a lista estiver vazia.
- Interface com fundo espacial animado.
- Buraco negro interativo que acompanha o mouse.
- Estrelas, constelações, nebulosas, planetas e meteoros.
- Cards personalizados com animações.

## 🛠️ Tecnologias utilizadas

- React Native
- Expo
- TypeScript
- JavaScript
- React Hooks (`useState`, `useEffect`)
- Canvas API (efeitos visuais da versão Web)

## 📚 Conceitos aplicados

- `TextInput` — entrada dos dados dos produtos.
- `Button` — adicionar produtos.
- Arrays — armazenamento dos itens.
- `FlatList` — renderização da lista.
- `TouchableOpacity` — remoção dos produtos.
- `useState` — gerenciamento de estado.
- Props — comunicação entre componentes.

## 📂 Estrutura do projeto

```text
orbitlist-galaxia/
├── components/
│   ├── Cabecalho.tsx
│   ├── FormularioItem.tsx
│   ├── ItemCompra.tsx
│   ├── ListaCompras.tsx
│   ├── GalaxyBackground.tsx
│   └── GalaxyBackground.web.tsx
├── App.tsx
├── index.tsx
├── types.ts
├── package.json
├── app.json
├── tsconfig.json
└── README.md
```

## ▶️ Como executar

É necessário ter o Node.js e o npm instalados.

**1. Instalar as dependências**

```bash
npm install
```

**2. Instalar dependências Web do Expo**

```bash
npx expo install react-dom react-native-web expo-status-bar
```

**3. Executar o aplicativo**

```bash
npx expo start --web
```

**4. Verificar os tipos**

```bash
npm run typecheck
```

## 🧪 Testes

| Teste | Resultado esperado |
|---|---|
| Abrir aplicativo | Exibir Maçã, Arroz e Leite |
| Adicionar Pão com quantidade 5 | Inserir Pão na lista |
| Adicionar Ovos sem quantidade | Usar quantidade padrão 1 |
| Adicionar produto sem nome | Mostrar aviso |
| Remover produto | Excluir o item selecionado |
| Remover todos os produtos | Mostrar mensagem de lista vazia |

## 📸 Captura de tela

![Tela do PinkList](screenshots/tela-inicial.png)

*O arquivo da imagem deve ser adicionado à pasta `screenshots`.*

## 🎯 Objetivo

Aplicar os conhecimentos de desenvolvimento mobile com React Native e Expo na criação de um aplicativo funcional de lista de compras, utilizando componentes, propriedades, estados, arrays e renderização de listas.

## 📝 Observação

Os efeitos interativos de mouse e Canvas são exclusivos da versão Web. A versão mobile utiliza um fundo simplificado.

## 📄 Licença

Projeto educacional desenvolvido para fins acadêmicos.

## 🎀 Tema visual

Interface em branco e rosa-claro, com cartões arredondados, detalhes delicados e textos em tons rosados.
