import { useCallback, useState } from 'react';
import { Platform, SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import Cabecalho from './components/Cabecalho';
import FormularioItem from './components/FormularioItem';
import ListaCompras from './components/ListaCompras';
import type { ItemDeCompra } from './types';

let nextId = 4;
export default function App() {
  const [itens, setItens] = useState<ItemDeCompra[]>([
    { id: '1', nome: 'Maçã', quantidade: 3 },
    { id: '2', nome: 'Arroz', quantidade: 1 },
    { id: '3', nome: 'Leite', quantidade: 2 },
  ]);
  const adicionarItem = useCallback((nome: string, quantidade: number) => {
    const item: ItemDeCompra = { id: `${Date.now()}-${nextId++}`, nome, quantidade };
    setItens((anteriores) => [...anteriores, item]);
  }, []);
  const removerItem = useCallback((id: string) => {
    setItens((anteriores) => anteriores.filter((item) => item.id !== id));
  }, []);

  return <SafeAreaView style={s.root}>
    <StatusBar style="dark" />
    <ScrollView style={s.scroller} contentContainerStyle={s.scrollContent} keyboardShouldPersistTaps="handled">
      <View style={s.page}>
        <View style={s.topbar}>
          <Text style={s.logo}>♡ PINK<Text style={s.logoAccent}>LIST</Text></Text>
          <View style={s.online}><View style={s.dot} /><Text style={s.onlineText}>MINHA LISTA</Text></View>
        </View>
        <Cabecalho />
        <View style={s.panel}>
          <FormularioItem aoAdicionar={adicionarItem} />
          <ListaCompras itens={itens} aoRemover={removerItem} />
          <View style={s.footer}><Text style={s.footerText}>♡  {itens.length} {itens.length === 1 ? 'item' : 'itens'} na lista</Text><Text style={s.footerSmall}>Organize suas compras com carinho</Text></View>
        </View>
        <Text style={s.bottomNote}> • FACILITANDO SEU DIA A DIA •</Text>
      </View>
    </ScrollView>
  </SafeAreaView>;
}
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#FFF7FA' },
  scroller: { flex: 1 },
  scrollContent: { flexGrow: 1, alignItems: 'center', paddingHorizontal: 18, paddingBottom: 30 },
  page: { width: '100%', maxWidth: 760, paddingTop: Platform.OS === 'web' ? 26 : 12 },
  topbar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  logo: { color: '#5B3444', fontSize: 17, letterSpacing: 1.5, fontWeight: '900' },
  logoAccent: { color: '#E75480' },
  online: { flexDirection: 'row', alignItems: 'center', gap: 7, borderColor: '#F4C5D5', borderWidth: 1, backgroundColor: '#FFFFFF', borderRadius: 30, paddingHorizontal: 12, paddingVertical: 8 },
  dot: { width: 7, height: 7, borderRadius: 5, backgroundColor: '#E75480' },
  onlineText: { color: '#B34C70', fontSize: 10, letterSpacing: 1, fontWeight: '800' },
  panel: { backgroundColor: '#FFFFFF', borderRadius: 26, borderColor: '#F6D7E2', borderWidth: 1, padding: 20, shadowColor: '#D96A91', shadowOpacity: 0.10, shadowRadius: 24, shadowOffset: { width: 0, height: 8 }, elevation: 3 },
  footer: { borderTopWidth: 1, borderTopColor: '#F8E5EC', paddingTop: 18, marginTop: 5, flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 10 },
  footerText: { color: '#D94F7B', fontWeight: '800', fontSize: 13 },
  footerSmall: { color: '#9A7A86', fontSize: 11 },
  bottomNote: { color: '#C08A9D', fontSize: 10, letterSpacing: 2, fontWeight: '700', textAlign: 'center', marginTop: 20 },
});
