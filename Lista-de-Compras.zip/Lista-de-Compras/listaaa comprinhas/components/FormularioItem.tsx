import { useState } from 'react';
import { Alert, Button, Platform, StyleSheet, Text, TextInput, View } from 'react-native';
type Props = { aoAdicionar: (nome: string, quantidade: number) => void };
export default function FormularioItem({ aoAdicionar }: Props) {
  const [nome, setNome] = useState('');
  const [quantidade, setQuantidade] = useState('');
  const [erro, setErro] = useState('');
  function lidarComAdicao() {
    if (!nome.trim()) {
      setErro('Digite o nome do produto antes de adicionar.');
      if (Platform.OS !== 'web') Alert.alert('Atenção', 'Digite o nome do produto.');
      return;
    }
    const n = Number.parseInt(quantidade, 10);
    const qtd = Number.isFinite(n) && n > 0 ? n : 1;
    aoAdicionar(nome.trim(), qtd);
    setNome(''); setQuantidade(''); setErro('');
  }
  return <View style={s.card}>
    <View style={s.heading}><Text style={s.cardTitle}>Adicionar produto</Text><Text style={s.caption}>NOVO ITEM +</Text></View>
    <Text style={s.label}>NOME DO PRODUTO</Text>
    <TextInput style={s.input} value={nome} onChangeText={(value) => { setNome(value); if (erro) setErro(''); }} placeholder="Ex.: Arroz, leite, café..." placeholderTextColor="#B7A2AB" returnKeyType="done" onSubmitEditing={lidarComAdicao} accessibilityLabel="Nome do produto" />
    <Text style={s.label}>QUANTIDADE</Text>
    <TextInput style={[s.input, s.quantity]} value={quantidade} onChangeText={setQuantidade} placeholder="1" placeholderTextColor="#B7A2AB" keyboardType="numeric" maxLength={3} accessibilityLabel="Quantidade" />
    {erro ? <Text style={s.error}>{erro}</Text> : null}
    <View style={s.buttonWrap}><Button title="＋  Adicionar à lista" color="#E75480" onPress={lidarComAdicao} /></View>
  </View>;
}
const s = StyleSheet.create({
  card: { backgroundColor: '#FFFAFC', borderColor: '#F6D8E3', borderWidth: 1, borderRadius: 20, padding: 20, marginBottom: 22 },
  heading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', marginBottom: 19, gap: 8 },
  cardTitle: { color: '#533642', fontSize: 18, fontWeight: '800' },
  caption: { color: '#D94F7B', fontSize: 10, fontWeight: '800', letterSpacing: 1.2, backgroundColor: '#FFEAF1', paddingHorizontal: 9, paddingVertical: 6, borderRadius: 20 },
  label: { color: '#9B6C7E', fontSize: 10, fontWeight: '800', letterSpacing: 1.2, marginBottom: 8 },
  input: { color: '#513541', borderColor: '#F0C9D7', borderWidth: 1, borderRadius: 12, backgroundColor: '#FFFFFF', paddingHorizontal: 15, paddingVertical: 12, fontSize: 15, marginBottom: 16, minHeight: 48 },
  quantity: { width: 118 },
  buttonWrap: { backgroundColor: '#E75480', borderRadius: 12, overflow: 'hidden', paddingVertical: 5 },
  error: { color: '#C52F5C', marginBottom: 12, fontSize: 13 },
});
