import { useEffect, useRef } from 'react';
import { Animated, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import type { ItemDeCompra } from '../types';
type Props = { item: ItemDeCompra; aoRemover: (id: string) => void; index: number };
export default function ItemCompra({ item, aoRemover, index }: Props) {
  const progress = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const animation = Animated.timing(progress, { toValue: 1, duration: 280 + Math.min(index, 8) * 40, useNativeDriver: true });
    animation.start(); return () => animation.stop();
  }, [progress, index]);
  return <Animated.View style={[s.card, { opacity: progress, transform: [{ translateY: progress.interpolate({ inputRange: [0, 1], outputRange: [12, 0] }) }] }]}>
    <View style={s.iconBox}><Text style={s.icon}>♡</Text></View>
    <View style={s.info}><Text style={s.name} numberOfLines={2}>{item.nome}</Text><Text style={s.meta}>Quantidade: {item.quantidade}</Text></View>
    <View style={s.pill}><Text style={s.pillText}>×{item.quantidade}</Text></View>
    <TouchableOpacity onPress={() => aoRemover(item.id)} style={s.remove} accessibilityRole="button" accessibilityLabel={`Remover ${item.nome}`} activeOpacity={0.6}><Text style={s.removeText}>×</Text></TouchableOpacity>
  </Animated.View>;
}
const s = StyleSheet.create({
  card: { flexDirection: 'row', alignItems: 'center', minHeight: 78, gap: 11, borderRadius: 15, padding: 12, marginBottom: 10, backgroundColor: '#FFFFFF', borderColor: '#F4DCE5', borderWidth: 1 },
  iconBox: { width: 42, height: 42, borderRadius: 13, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFEAF1' },
  icon: { fontSize: 23, color: '#E75480' },
  info: { flex: 1 }, name: { color: '#533642', fontSize: 15, fontWeight: '700' }, meta: { color: '#A0838E', fontSize: 12, marginTop: 4 },
  pill: { paddingHorizontal: 9, paddingVertical: 6, backgroundColor: '#FFEAF1', borderRadius: 9 }, pillText: { color: '#C64D76', fontWeight: '800', fontSize: 12 },
  remove: { width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFF0F4' }, removeText: { color: '#D94F7B', fontSize: 24, lineHeight: 29 },
});
