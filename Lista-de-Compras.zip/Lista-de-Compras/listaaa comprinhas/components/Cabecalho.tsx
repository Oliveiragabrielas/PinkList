import { View, Text, StyleSheet } from 'react-native';
export default function Cabecalho() {
  return <View style={s.wrapper}>
    <View style={s.eyebrow}><Text style={s.eyebrowText}>♡  ORGANIZE SUA ROTINA  ♡</Text></View>
    <View style={s.emojiCircle}><Text style={s.emoji}>🛍️</Text></View>
    <Text style={s.title}>Minha lista de</Text>
    <Text style={s.title}><Text style={s.highlight}>compras</Text></Text>
    <Text style={s.subtitle}>Tudo o que você precisa, em um só lugar.</Text>
  </View>;
}
const s = StyleSheet.create({
  wrapper: { alignItems: 'center', marginBottom: 25, paddingTop: 8 },
  eyebrow: { backgroundColor: '#FFEAF1', borderWidth: 1, borderColor: '#F8C8D8', borderRadius: 30, paddingHorizontal: 16, paddingVertical: 8, marginBottom: 18 },
  eyebrowText: { color: '#C64D76', fontSize: 10, fontWeight: '800', letterSpacing: 1.5 },
  emojiCircle: { width: 74, height: 74, borderRadius: 25, backgroundColor: '#FFE4ED', alignItems: 'center', justifyContent: 'center', marginBottom: 13 },
  emoji: { fontSize: 37 },
  title: { color: '#4C303B', fontSize: 30, fontWeight: '800', textAlign: 'center', letterSpacing: -0.7 },
  highlight: { color: '#E75480' },
  subtitle: { color: '#987987', fontSize: 14, marginTop: 10, textAlign: 'center' },
});
