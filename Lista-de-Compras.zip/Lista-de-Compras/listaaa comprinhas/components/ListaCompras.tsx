import { FlatList, StyleSheet, Text, View } from 'react-native';
import ItemCompra from './ItemCompra';
import type { ItemDeCompra } from '../types';
type Props = { itens: ItemDeCompra[]; aoRemover: (id: string) => void };
export default function ListaCompras({ itens, aoRemover }: Props) {
  return <View style={s.container}>
    <View style={s.top}><Text style={s.title}>Seus produtos</Text><Text style={s.count}>{itens.length} {itens.length === 1 ? 'ITEM' : 'ITENS'}</Text></View>
    <FlatList data={itens} keyExtractor={(item) => item.id} renderItem={({ item, index }) => <ItemCompra item={item} aoRemover={aoRemover} index={index} />}
      ListEmptyComponent={<View style={s.empty}><Text style={s.emptyIcon}>🛍️</Text><Text style={s.emptyTitle}>Sua lista está vazia</Text><Text style={s.emptyText}>Adicione seu primeiro produto para começar.</Text></View>}
      contentContainerStyle={s.list} keyboardShouldPersistTaps="handled" />
  </View>;
}
const s = StyleSheet.create({
  container: { flex: 1, minHeight: 180 }, top: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  title: { color: '#533642', fontSize: 19, fontWeight: '800' },
  count: { color: '#D94F7B', fontSize: 11, fontWeight: '800', letterSpacing: 1.1, backgroundColor: '#FFEAF1', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20 },
  list: { paddingBottom: 18, flexGrow: 1 },
  empty: { alignItems: 'center', justifyContent: 'center', minHeight: 170, backgroundColor: '#FFFAFC', borderWidth: 1, borderColor: '#F4DCE5', borderRadius: 18, padding: 22 },
  emptyIcon: { fontSize: 35, marginBottom: 12 }, emptyTitle: { color: '#533642', fontSize: 17, fontWeight: '700' }, emptyText: { color: '#A0838E', fontSize: 12, marginTop: 7, textAlign: 'center' },
});
