import { View, StyleSheet } from 'react-native';
// Fallback leve para Android/iOS. Partículas animadas e mouse são exclusivos da web.
const pontos = Array.from({ length: 34 }, (_, i) => ({
  left: `${(i * 37.7) % 98}%` as `${number}%`,
  top: `${(i * 23.9) % 98}%` as `${number}%`,
  size: i % 4 === 0 ? 3 : 2,
}));
export default function GalaxyBackground() {
  return <View pointerEvents="none" style={StyleSheet.absoluteFill}>
    {pontos.map((p, i) => <View key={i} style={{ position: 'absolute', left: p.left, top: p.top, width: p.size, height: p.size, borderRadius: 5, backgroundColor: '#7D74BA', opacity: 0.5 }} />)}
  </View>;
}
