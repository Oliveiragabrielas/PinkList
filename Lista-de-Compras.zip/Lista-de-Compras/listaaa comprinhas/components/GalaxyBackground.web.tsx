import { useEffect, useRef } from 'react';

type Star = { x: number; y: number; vx: number; vy: number; size: number; phase: number; alpha: number; depth: number };
type Meteor = { x: number; y: number; vx: number; vy: number; life: number; maxLife: number };
const TAU = Math.PI * 2;
const rand = (a: number, b: number) => a + Math.random() * (b - a);

/** Fundo Canvas otimizado: nenhum setState por frame, pointerEvents desativados. */
export default function GalaxyBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d', { alpha: true });
    if (!canvas || !ctx) return;

    let w = 0, h = 0, dpr = 1, raf = 0, last = 0, elapsed = 0, meteorTimer = 0;
    let running = !document.hidden;
    const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
    let reduced = motion.matches;
    const pointer = { x: -9999, y: -9999, active: false };
    const hole = { x: 0, y: 0 };
    let stars: Star[] = [];
    let meteors: Meteor[] = [];
    const isSmall = () => w < 650;

    function resize() {
      w = window.innerWidth; h = window.innerHeight;
      dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas!.width = Math.round(w * dpr); canvas!.height = Math.round(h * dpr);
      canvas!.style.width = `${w}px`; canvas!.style.height = `${h}px`;
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
      const n = Math.min(175, Math.max(65, Math.round(w * h / 9300)));
      stars = Array.from({ length: n }, () => ({
        x: Math.random() * w, y: Math.random() * h,
        vx: rand(-0.12, 0.12), vy: rand(-0.09, 0.09),
        size: rand(0.45, 1.6), phase: rand(0, TAU), alpha: rand(0.3, 0.9), depth: rand(0.65, 1.5),
      }));
      if (!pointer.active) { hole.x = w * 0.76; hole.y = h * 0.68; }
    }

    function planet(x: number, y: number, r: number, t: number, colorA: string, colorB: string, ring: boolean) {
      const halo = ctx!.createRadialGradient(x, y, r * 0.4, x, y, r * 2.1);
      halo.addColorStop(0, 'rgba(99,72,216,0.14)'); halo.addColorStop(1, 'rgba(99,72,216,0)');
      ctx!.fillStyle = halo; ctx!.beginPath(); ctx!.arc(x, y, r * 2.1, 0, TAU); ctx!.fill();
      if (ring) {
        ctx!.save(); ctx!.translate(x, y); ctx!.rotate(-0.34);
        ctx!.strokeStyle = 'rgba(171,143,255,0.34)'; ctx!.lineWidth = Math.max(2, r * 0.13);
        ctx!.beginPath(); ctx!.ellipse(0, 0, r * 1.6, r * 0.42, 0, Math.PI, TAU); ctx!.stroke(); ctx!.restore();
      }
      const surface = ctx!.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.05, x, y, r);
      surface.addColorStop(0, colorA); surface.addColorStop(0.56, colorB); surface.addColorStop(1, '#08071e');
      ctx!.fillStyle = surface; ctx!.beginPath(); ctx!.arc(x, y, r, 0, TAU); ctx!.fill();
      ctx!.save(); ctx!.beginPath(); ctx!.arc(x, y, r, 0, TAU); ctx!.clip();
      ctx!.strokeStyle = 'rgba(225,201,255,0.12)'; ctx!.lineWidth = Math.max(2, r * 0.12);
      for (let j = 0; j < 3; j++) {
        const yy = y + Math.sin(t * 0.13 + j * 1.8) * r * 0.45;
        ctx!.beginPath(); ctx!.ellipse(x + Math.sin(t * 0.19 + j) * r * 0.32, yy, r, r * 0.22, -0.16, 0, TAU); ctx!.stroke();
      }
      ctx!.restore();
      if (ring) {
        ctx!.save(); ctx!.translate(x, y); ctx!.rotate(-0.34);
        ctx!.strokeStyle = 'rgba(213,185,255,0.62)'; ctx!.lineWidth = Math.max(2, r * 0.13);
        ctx!.beginPath(); ctx!.ellipse(0, 0, r * 1.6, r * 0.42, 0, 0, Math.PI); ctx!.stroke(); ctx!.restore();
      }
    }

    function blackHole(x: number, y: number, t: number, scale: number) {
      ctx!.save(); ctx!.translate(x, y);
      const halo = ctx!.createRadialGradient(0, 0, 14 * scale, 0, 0, 190 * scale);
      halo.addColorStop(0, 'rgba(145,85,255,0.30)');
      halo.addColorStop(0.3, 'rgba(101,54,225,0.15)');
      halo.addColorStop(1, 'rgba(101,54,225,0)');
      ctx!.fillStyle = halo; ctx!.beginPath(); ctx!.arc(0, 0, 190 * scale, 0, TAU); ctx!.fill();
      ctx!.rotate(t * 0.13);
      for (let i = 0; i < 4; i++) {
        ctx!.beginPath(); ctx!.ellipse(0, 0, (55 + i * 9) * scale, (19 + i * 4) * scale, -0.27, 0, TAU);
        ctx!.strokeStyle = ['rgba(164,93,255,.33)', 'rgba(235,151,255,.55)', 'rgba(101,113,255,.44)', 'rgba(224,143,255,.18)'][i];
        ctx!.lineWidth = (7 - i) * scale; ctx!.stroke();
      }
      ctx!.rotate(-t * 0.13);
      const photon = ctx!.createRadialGradient(0, 0, 26 * scale, 0, 0, 46 * scale);
      photon.addColorStop(0, '#010109'); photon.addColorStop(0.66, '#010109');
      photon.addColorStop(0.77, 'rgba(239,201,255,0.93)'); photon.addColorStop(0.9, 'rgba(140,75,255,0.64)');
      photon.addColorStop(1, 'rgba(140,75,255,0)');
      ctx!.fillStyle = photon; ctx!.beginPath(); ctx!.arc(0, 0, 46 * scale, 0, TAU); ctx!.fill();
      ctx!.fillStyle = '#010109'; ctx!.beginPath(); ctx!.arc(0, 0, 33 * scale, 0, TAU); ctx!.fill();
      ctx!.restore();
    }

    function render(now: number) {
      if (!running) return;
      raf = requestAnimationFrame(render);
      if (now - last < (reduced ? 95 : 32)) return; // ~30 FPS, respeita redução de movimento
      const dt = Math.min((now - (last || now)) / 33, 2); last = now;
      elapsed += reduced ? 0 : dt * 0.033;
      ctx!.clearRect(0, 0, w, h);
      const t = elapsed;
      const destX = pointer.active ? pointer.x : w * 0.78;
      const destY = pointer.active ? pointer.y : h * 0.72;
      hole.x += (destX - hole.x) * (reduced ? 1 : 0.07);
      hole.y += (destY - hole.y) * (reduced ? 1 : 0.07);
      const scale = isSmall() ? 0.64 : 1;

      const haze = ctx!.createRadialGradient(w * .2, h * .12, 0, w * .2, h * .12, Math.max(w, h) * 0.85);
      haze.addColorStop(0, 'rgba(80,32,160,.13)'); haze.addColorStop(1, 'rgba(5,4,20,0)');
      ctx!.fillStyle = haze; ctx!.fillRect(0, 0, w, h);

      planet(w * .11, h * .23, Math.min(52, w * .095), t, '#9580ed', '#392177', true);
      if (!isSmall()) planet(w * .89, h * .24, 30, t + 6, '#78b2f4', '#273e8a', false);
      planet(w * .91, h * .86, Math.min(70, w * .1), t + 12, '#c36cb8', '#4c205c', false);

      // Conexões: apenas estrelas próximas, para limitar o custo de desenho.
      for (let i = 0; i < stars.length; i++) {
        const a = stars[i];
        for (let j = i + 1; j < stars.length; j++) {
          const b = stars[j]; const dx = a.x - b.x, dy = a.y - b.y;
          const dd = dx * dx + dy * dy;
          if (dd < 105 * 105 && dd > 20 * 20) {
            ctx!.strokeStyle = `rgba(163,132,255,${(1 - dd / (105 * 105)) * 0.15})`;
            ctx!.lineWidth = 0.55; ctx!.beginPath(); ctx!.moveTo(a.x, a.y); ctx!.lineTo(b.x, b.y); ctx!.stroke();
          }
        }
      }

      for (const s of stars) {
        if (!reduced) {
          s.x = (s.x + s.vx * dt + w) % w;
          s.y = (s.y + s.vy * dt + h) % h;
        }
        const dx = hole.x - s.x, dy = hole.y - s.y;
        const dist = Math.hypot(dx, dy) || 1;
        const influence = Math.max(0, 1 - dist / (225 * scale));
        // Distorção VISUAL reversível, sem alterar definitivamente a órbita da estrela.
        const bend = influence * influence * 35 * scale * s.depth;
        const sx = s.x + dx / dist * bend, sy = s.y + dy / dist * bend;
        const alpha = s.alpha * (0.75 + 0.25 * Math.sin(t * 1.6 + s.phase));
        ctx!.fillStyle = `rgba(224,211,255,${alpha})`;
        ctx!.beginPath(); ctx!.arc(sx, sy, s.size, 0, TAU); ctx!.fill();
      }

      if (!reduced) {
        meteorTimer += dt;
        if (meteorTimer > 100 && meteors.length < 2) {
          meteorTimer = 0;
          meteors.push({ x: rand(-40, w * 0.85), y: rand(-30, h * 0.4), vx: rand(7, 11), vy: rand(3, 5), life: 0, maxLife: rand(40, 75) });
        }
      }
      for (let i = meteors.length - 1; i >= 0; i--) {
        const m = meteors[i]; if (!reduced) { m.x += m.vx * dt; m.y += m.vy * dt; m.life += dt; }
        const opacity = Math.min(1, (m.maxLife - m.life) / 16);
        const trail = ctx!.createLinearGradient(m.x, m.y, m.x - m.vx * 12, m.y - m.vy * 12);
        trail.addColorStop(0, `rgba(240,225,255,${opacity})`);
        trail.addColorStop(1, 'rgba(155,109,255,0)');
        ctx!.strokeStyle = trail; ctx!.lineWidth = 2;
        ctx!.beginPath(); ctx!.moveTo(m.x, m.y); ctx!.lineTo(m.x - m.vx * 12, m.y - m.vy * 12); ctx!.stroke();
        if (m.life > m.maxLife) meteors.splice(i, 1);
      }

      blackHole(hole.x, hole.y, t, scale);
    }

    function onPointer(e: PointerEvent) {
      if (e.pointerType === 'touch') return;
      pointer.active = true; pointer.x = e.clientX; pointer.y = e.clientY;
    }
    function onLeave() { pointer.active = false; }
    function onVisibility() {
      running = !document.hidden;
      if (running) { last = 0; raf = requestAnimationFrame(render); }
      else cancelAnimationFrame(raf);
    }
    function onMotion() { reduced = motion.matches; }
    resize(); raf = requestAnimationFrame(render);
    window.addEventListener('resize', resize);
    window.addEventListener('pointermove', onPointer, { passive: true });
    window.addEventListener('blur', onLeave);
    document.addEventListener('visibilitychange', onVisibility);
    motion.addEventListener?.('change', onMotion);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      window.removeEventListener('pointermove', onPointer);
      window.removeEventListener('blur', onLeave);
      document.removeEventListener('visibilitychange', onVisibility);
      motion.removeEventListener?.('change', onMotion);
    };
  }, []);

  return <canvas ref={canvasRef} aria-hidden="true" style={{ position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none' }} />;
}
